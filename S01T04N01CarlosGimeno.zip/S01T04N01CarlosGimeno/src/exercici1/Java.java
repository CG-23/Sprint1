package exercici1;

import java.util.ArrayList;

public class Java {
	
	public void java () {		
	}
	
	public static ArrayList<String> afegirMesos () {
		ArrayList<String>LlistaMesos = new ArrayList<String>();
		
		LlistaMesos.add("Gener");
		LlistaMesos.add("Febrer");
		LlistaMesos.add("Març");
		LlistaMesos.add("Abril");
		LlistaMesos.add("Maig");
		LlistaMesos.add("Juny");
		LlistaMesos.add("Juliol");
		LlistaMesos.add("Agost");
		LlistaMesos.add("Septembre");
		LlistaMesos.add("Octubre");
		LlistaMesos.add("Novembre");
		LlistaMesos.add("Desembre");
		
		return (LlistaMesos);
	}
}
